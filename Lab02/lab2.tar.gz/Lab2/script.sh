#!/bin/bash
date
current_time=$(date +%s)
echo $current_time
echo $((current_time*2))
for i in {1..20}; do
	echo $i
done
wget  https://elearning.auth.gr/mod/resource/view.php?id=204582      
